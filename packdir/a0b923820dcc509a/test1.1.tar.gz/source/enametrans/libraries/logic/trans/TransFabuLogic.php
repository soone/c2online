<?php
class TransFabuLogic
{
	private $EnameId;
	private $lib;
	public function __construct($EnameId)
	{
		$this->EnameId = $EnameId;
		$this->lib = new TransFabuLib($EnameId);
	}

	//区分域名
	public function firstLogic(MY_Controller $ctrl)
	{
		Logger::log(AUCTION_LOG."FABU", array('FABU', "InEname", "================FirstFaBu Start=================="));
		$transType = ReturnData::$info->transType;
		$domainNames = ReturnData::$info->domainName;
		if($domainNames)
		{
			
			//检查是否是有效的交易类型
			$isTransType = $this->lib->checkIsValidTransType($ctrl, $transType);
			if($isTransType)
			{
				PublicLib::formatDomainArray($domainNames);//格式化成数组
				$maxNum	= $ctrl->config->item('fabu_domains_max_num');	//一次性发布域名交易数量限制
				if(count($domainNames) <= $maxNum)
				{	
					list($inEname,$notUser,$notInEname) = $this->lib->checkUserDomains($domainNames);
					list($able,$unable) = $this->lib->doInEname($ctrl, $inEname);//operate in ename
					list($authing,$notAuth) = $this->lib->doNotInEname($ctrl, $notInEname);//operate not in ename 
					$mixUnable = array_merge($unable,$authing,$notAuth,$notUser);
					$transtopic 	= $this->lib->getVaildTopic();			//获取专题名称
					$transPoundage  = $this->lib->getPoundageType(); 	//预付款方式 
					$transTypeCn 	= $ctrl->config->item('fabu_transtype');
					$sid		= $ctrl->config->item('fabu_sid');
					$afterAuditConf	= $ctrl->config->item('fabu_after_audit');
					$transTopicConf	= $ctrl->config->item('fabu_transtopic');
					$userSetting 	= $this->lib->getUserSetting($ctrl); 
					$transSpecialType = $ctrl->config->item('fabu_special_domain_type');
					$transSpecialTypeCn = PrivateLib::KeyToValue($ctrl->config->item('fabu_special_domain_type'));
					$array = array(	'transType'=>$transType,
							'transTypeCn'=>$transTypeCn,
							'transTopic'=>$transtopic,
							'transTopicConf'=>$transTopicConf,
							'afterAuditConf'=>$afterAuditConf,
							'transPoundage'=>$transPoundage,
							'userSetting'=>$userSetting,
							'sid'=>$sid,
							'able'=>$able,
							'mixUnable'=>$mixUnable,
							'transSpecialType'=>$ctrl->config->item('fabu_special_domain_type'),
							'transSpecialTypeCn'=>PrivateLib::KeyToValue($ctrl->config->item('fabu_special_domain_type')),
						);
					Logger::log(AUCTION_LOG."FABU", array('FABU', "InEname", "================FirstFaBu End=================="));
					return $array;
				}
				else
				{
					Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'checkDomainNum', 'False', count($domainNames), $this->EnameId));
					Logger::log(AUCTION_LOG."FABU", array('FABU', "InEname", "================FirstFaBu End=================="));
					throw new Exception ( '每次同时只能发布20个域名' );
				}
			}
			else
			{
				Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'checkTransType', 'False', $transType, $this->EnameId));
				Logger::log(AUCTION_LOG."FABU", array('FABU', "InEname", "================FirstFaBu End=================="));
				throw new Exception("非法操作");
			}
		}
		else
		{
			Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'checkDomain', 'False', $this->EnameId));
			Logger::log(AUCTION_LOG."FABU", array('FABU', "InEname", "================FirstFaBu End=================="));
			throw new Exception('请输入域名');
		}
	}

	//设置页面
	public function secondLogic(MY_Controller $ctrl)
	{
		Logger::log(AUCTION_LOG."FABU", array('FABU', "InEname", "================SecondFaBu Start=================="));
		$fabuLib2 = new TransFabu2Lib($this->EnameId);
		$fabuLib2->checkSecuritySetting($ctrl, $this->EnameId);

		$fabuFalseTypeConf 	= $ctrl->config->item('fabu_false_type');
		$authStatusConf 	= $ctrl->config->item('fabu_auth_status');
		$refreshStatusConf 	= $ctrl->config->item('fabu_refresh_status');
		$transTypeConf		= $ctrl->config->item('fabu_transtypeinfo');	//获取交易类型
		$maxNum 			= $ctrl->config->item('fabu_domains_max_num');	//一次性发布域名交易数量限制
		$auditStatusConf 	= $ctrl->config->item('fabu_audit_status');
		$afterAuditConf 	= $ctrl->config->item('fabu_after_audit');
		$inEnameConf 		= $ctrl->config->item('fabu_reg');
		//获取有效的专题拍卖类型
		$validTopicIds = $fabuLib2->getVaildTopicClassIds();
		//获取提现与不可提现配置
		$poundageTypeConf = $fabuLib2->getPoundageType();
		
		//参数默认值
		$haveAuditDomain = false;
		$haveAuctionDomain = false;
		$haveInquiryDomain =false;
		$domainAuthStatus = $authStatusConf['auth'][0];
		$isInEname = $inEnameConf['inename'][0];
		$sellerOrderId = 0;
		$doDomains = array('url'=>array(), 'falseDomains'=>array(), 'fabuSuccessDomains'=>array());
		
		$domains	 = $_POST["domains"];
		foreach ($domains AS $k=>$domain)
		{
			//表单字段名转换（域名中的.转成_）
			$domainTag = $fabuLib2->postFieldConvert($domain);
			$checkRes = $fabuLib2->checkPostData($ctrl, $domain, $domainTag, $validTopicIds, $poundageTypeConf);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "checkPostData", $domain, $this->EnameId));
			if($checkRes===false)
			{
				Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'checkPostField', 'False', $domain, $fabuFalseTypeConf['unValidPostData'][1]));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['unValidPostData'][1]);
				continue;
			}
			
			$Tlib = new TransLib();
			$rs = $Tlib->checkQQdomain($domain);
			if($rs && $_POST[$domainTag.'_transtype'] == $transTypeConf['inquiry'][0])
			{
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['unValidPostData'][1]);
				continue;
			}
			
			
			//询价，检查是否已经发布过
			$isOnSale = $fabuLib2->checkIsOnSale($ctrl, $domain, $_POST[$domainTag.'_transtype']);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "checkIsOnSale", $domain, $this->EnameId));
			if($isOnSale)
			{
				Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'checkIsOnSale', 'False', $domain, $fabuFalseTypeConf['isReleaseInquiry'][1]));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['isReleaseInquiry'][1]);
				continue;
			}
			
			//检查是否是易拍易卖或专题拍卖
			$isEbuyAndTopic = $fabuLib2->checkIsEbuyAndTopic($ctrl, $_POST[$domainTag."_transtopic"]);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "checkIsEbuyAndTopic", $domain, $this->EnameId));
			if($isEbuyAndTopic)
			{
				Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "checkIsEbuyAndTopic", "IsEbuyAndTopic",$domain, $this->EnameId));
				//进行相关检查
				$rs = $fabuLib2->checkEbuyAndTopic($ctrl, $domain, $_POST[$domainTag.'_transtype']);
				if($rs[0]==false)
				{
					Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'checkEbuyAndTopic', 'False', $domain, $this->EnameId, $rs[1]));
					$doDomains['falseDomains'][] = array($domain, $rs[1]);
					continue;
				}
				$auditStatus = $auditStatusConf['noAudit'][0];
				$auditer = 0;
				$haveAuditDomain = true;
			}
			else 
			{
				Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "checkIsEbuyAndTopic", "NotIsEbuyAndTopic",$domain, $this->EnameId));
				$auditStatus = $auditStatusConf['auditPass'][0];
				$auditer = $ctrl->config->item('fabu_default_auditer');
			}

			//获取相关交易信息
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "getTransData", $domain, $this->EnameId));
			$transData = $fabuLib2->getTransData($ctrl, $domain, $_POST[$domainTag.'_transtype'], $_POST[$domainTag.'_transmoney'],
								$_POST[$domainTag.'_transtime'], $_POST[$domainTag.'_transdate'], $_POST[$domainTag.'_simpledec'], 
								$_POST[$domainTag.'_fulldec'], $auditer, $_POST[$domainTag.'_transtopic_fail'], $auditStatus, 
								$domainAuthStatus, $_POST[$domainTag.'_transpoundage'], $_POST[$domainTag.'_transtopic'], 
								$_POST[$domainTag.'_transtopicname'], $isInEname, $sellerOrderId);
			
			//锁定域名
			$lockRs = $fabuLib2->lockDomain($ctrl, $domain, $_POST[$domainTag.'_transtype']);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "lockDomain", $domain, $this->EnameId));
			if($lockRs==false)
			{
				Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'lockDomain', 'False', $domain));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['sysError'][1]);
				continue;
			}
			
			//写入Audit表
			$auditListId = $fabuLib2->addAuditDomain($transData);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "addAuditDomain", $auditListId, $domain, $this->EnameId));
			if($auditListId==false)
			{
				Logger::log(AUCTION_LOG.'FABU', array('FABU', 'InEname', 'addAuditDomain', 'False', $domain, $this->EnameId));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['addTableFalse'][1]);
				continue;
			}
			
			if($isEbuyAndTopic==false)
			{
				$transData['auditListId'] = $auditListId;
				if($_POST[$domainTag.'_transtype']==$transTypeConf['inquiry'][0])
				{
					//写入inquiry表
					$rs = $fabuLib2->addInquiryDomain($ctrl, $transData);
					Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "addInquiryDomain", $rs, $domain, $this->EnameId));
					if($rs==false)
					{
						Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "addInquiryDomain", "False", $domain, $this->EnameId));
						$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['addTableFalse'][1]);
						continue;
					}
					$haveInquiryDomain = true;
				}
				else
				{
					//写入auction表
					$rs = $fabuLib2->addAuctionDomain($transData);
					Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "addAuctionDomain", $rs, $domain, $this->EnameId));
					if($rs==false)
					{
						Logger::log(AUCTION_LOG.'FABU', array("FABU", "InEname", "addAuctionDomain", "False", $domain, $this->EnameId));
						$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['addTableFalse'][1]);
						continue;
					}
					$haveAuctionDomain = true;
				}
			}
			$doDomains['fabuSuccessDomains'][] = $domain;
		}
		Logger::log(AUCTION_LOG."FABU", array('FABU', "InEname", "================SecondFaBu End=================="));
		
		//获取相关URL
		$doDomains['url'] = $fabuLib2->getURLs(true, $haveAuctionDomain, $haveInquiryDomain, $haveAuditDomain);
		
		return $doDomains;
	}
	
	
	/**
	 * AJAX操作保护验证
	 */
	public function checkOperation()
	{
		//判断是否是模拟登陆
		$isAdminLogin = WebVisitor::getServiceName();
		if($isAdminLogin===false)
		{
			$pUserLib = new PublicUserLib();
				
			$QuestionId		 = ReturnData::$info->opProtectId;
			$Answer			 = ReturnData::$info->opAnswer;
			$Password		 = ReturnData::$info->opPassword;
			$EnameId		 = $this->EnameId;
				
			$qc = $pUserLib->checkOPAnswer($QuestionId, $Answer);
			$pc = $pUserLib->checkPassword($EnameId, $Password);
				
			if(!$qc)
			{
				echo json_encode(array("result"=>'1'));		//问题答案错误
			}
			else
			{
				if(!$pc)
				{
					echo json_encode(array("result"=>'2'));	//密码错误
				}
				else
				{
					echo json_encode(array("result"=>'3'));	//验证通过
				}
			}
		}
		else
		{
			echo json_encode(array("result"=>'3'));	//验证通过
		}
	}
		
	/**
	 * 发送手机或电话验证码
	 */
	public function sendCaptchaCode()
	{
		$type = ReturnData::$info->type;
		$EnameId = $this->EnameId;
		$pUserLib = new PublicUserLib();
		switch ($type)
		{
			case 1 : $rs = $pUserLib->sendMobileSmsCaptcha($EnameId);break;
			case 2 : $rs = $pUserLib->sendMobileVoiceCaptcha($EnameId);break;
			case 3 : $rs = $pUserLib->sendPhoneVoiceCaptcha($EnameId);break;
		}
		
		if($rs['code']==2008)
		{
			echo json_encode(array("result"=>"todaylimit"));
		}
		else
		{
			echo json_encode(array("result"=>$rs['data']));
		}
	}
	
	/**
	 * 检查手机或电话验证码
	 */
	public function checkCaptchaCode()
	{
		//判断是否是模拟登陆
		$isAdminLogin = WebVisitor::getServiceName();
		if($isAdminLogin===false)
		{
			$pUserLib = new PublicUserLib();
				
			$captchaCode	 = ReturnData::$info->captchaCode;
			$EnameId		 = $this->EnameId;
				
			$rs = $pUserLib->checkCaptchaCode($EnameId, $captchaCode);
				
			if($rs['code']==1000)
			{
				echo json_encode(array("result"=>'1'));
			}
			else
			{
				echo json_encode(array("result"=>$rs['data']));
			}
		}
		else
		{
			echo json_encode(array("result"=>'1'));
		}
	}


	/***********************************
	 *
	 * 非我司域名认证发布
	 *
	**********************************/
	public function notInEnameDomainFirstLogic(MY_Controller $ctrl)
	{
		 Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "================FirstFaBu Start=================="));
		 $authListIds = ReturnData::$info->authListId;
		 list($authpass, $authfail) = $this->lib->getAuthDomains($ctrl, $authListIds, date("Y-m-d"));
		 
		 $refreshStatusConf	= $ctrl->config->item('fabu_refresh_status');
		 $transTopicConf	= $ctrl->config->item('fabu_transtopic');
		 $afterAuditConf 	= $ctrl->config->item('fabu_after_audit');
		 $transTypeConf		= $ctrl->config->item('fabu_transtypeinfo');	//获取交易类型
		 $maxNum 			= $ctrl->config->item('fabu_domains_max_num');	//一次性发布域名交易数量限制
		 
		 if(count($authpass) <= $maxNum)
		 {
		 	list($inEname,$notInEname) = $this->lib->checkUserDomainsReg($authpass);
		 	list($able,$unable) = $this->lib->doForAuthFabu($ctrl, $notInEname);
		 	
		 	$mixUnable = array_merge($unable,$inEname,$authfail);
		 	$transtopic 	= $this->lib->getVaildTopic();			//获取专题名称
		 	$transPoundage  = $this->lib->getPoundageType(); 	//预付款方式
		 	$transTypeCn 	= $ctrl->config->item('fabu_transtype');
		 	$sid		= $ctrl->config->item('fabu_sid');
		 	$afterAuditConf	= $ctrl->config->item('fabu_after_audit');
		 	$transTopicConf	= $ctrl->config->item('fabu_transtopic');
		 	$userSetting 	= $this->lib->getUserSetting($ctrl);
		 	$transSpecialType = $ctrl->config->item('fabu_special_domain_type');
		 	$transSpecialTypeCn = PrivateLib::KeyToValue($ctrl->config->item('fabu_special_domain_type'));
		 	$array = array(
		 			'transTypeCn'=>$transTypeCn,
		 			'transTopic'=>$transtopic,
		 			'transTopicConf'=>$transTopicConf,
		 			'afterAuditConf'=>$afterAuditConf,
		 			'transPoundage'=>$transPoundage,
		 			'userSetting'=>$userSetting,
		 			'sid'=>$sid,
		 			'able'=>$able,
		 			'mixUnable'=>$mixUnable,
		 			'transSpecialType'=>$ctrl->config->item('fabu_special_domain_type'),
		 			'transSpecialTypeCn'=>PrivateLib::KeyToValue($ctrl->config->item('fabu_special_domain_type')),
		 	);
		 	Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "================FirstFaBu End=================="));
	 	 	return $array;
	 	 }
		 else
	 	 {
	 	 	Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "checkDomainNum", "False", count($authpass)));
	 	 	Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "================FirstFaBu End=================="));
	 		throw new Exception ( '每次同时只能发布20个域名' );
	 	 }
		 	
	}
	
	public function notInEnameDomainSecondLogic(MY_Controller $ctrl)
	{
	 	Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "================SecondFaBu Start=================="));
		$fabuLib2 = new TransFabu2Lib($this->EnameId);
		$fabuLib2->checkSecuritySetting($ctrl, $this->EnameId);
		
		$fabuFalseTypeConf  = $ctrl->config->item('fabu_false_type');
		$authStatusConf 	= $ctrl->config->item('fabu_auth_status');
		$refreshStatusConf 	= $ctrl->config->item('fabu_refresh_status');
		$transTypeConf		= $ctrl->config->item('fabu_transtypeinfo');	//获取交易类型
		$maxNum 			= $ctrl->config->item('fabu_domains_max_num');	//一次性发布域名交易数量限制
		$auditStatusConf 	= $ctrl->config->item('fabu_audit_status');
		$afterAuditConf 	= $ctrl->config->item('fabu_after_audit');
		$inEnameConf 		= $ctrl->config->item('fabu_reg');
		//获取有效的专题拍卖类型
		$validTopicIds = $fabuLib2->getVaildTopicClassIds();
		//获取提现与不可提现配置
		$poundageTypeConf = $fabuLib2->getPoundageType();
		
		//参数默认值
		$haveAuditDomain = false;
		$haveAuctionDomain = false;
		$haveInquiryDomain =false;
		$domainAuthStatus = $authStatusConf['auth'][0];
		$isInEname = $inEnameConf['notinename'][0];
		$sellerOrderId = 0;
		$doDomains = array('url'=>array(), 'falseDomains'=>array(), 'fabuSuccessDomains'=>array());

		$domains		 = $_POST["domains"];
		foreach ($domains AS $k=>$domain)
		{			
			//表单字段名转换（域名中的.转成_）
			$domainTag = $fabuLib2->postFieldConvert($domain);
			$checkRes = $fabuLib2->checkPostData($ctrl, $domain, $domainTag, $validTopicIds, $poundageTypeConf);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkPostData", $domain, $this->EnameId));
			if($checkRes===false)
			{
				Logger::log(AUCTION_LOG.'FABU', array('FABU', 'NotInEname', 'checkPostField', 'False', $domain, $fabuFalseTypeConf['unValidPostData'][1]));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['unValidPostData'][1]);
				continue;
			}

			//检查域名是否正在交易
			$isOnSale = $this->lib->isOnSale($ctrl, $domain, $_POST[$domainTag.'_transtype']);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkIsOnSale", $domain, $this->EnameId));
			if ($isOnSale)
			{
				Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkIsOnSale", "False", $domain, $this->EnameId, $fabuFalseTypeConf['domainIsOnSale'][1]));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['domainIsOnSale'][1]);
				continue;
			}
			
			//检查是否已经在等待审核列表
			$isWaitAuditDomain = $fabuLib2->checkIsWaitAuditDomain($ctrl, $this->EnameId, $domain);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkIsWaitAuditDomain", $domain, $this->EnameId));
			if($isWaitAuditDomain)
			{
				Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkIsWaitAuditDomain", "False", $domain, $this->EnameId, $fabuFalseTypeConf['inWaitAuditList'][1]));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['inWaitAuditList'][1]);
				continue;
			}
			
			//检查是否是易拍易卖或专题拍卖
			$isEbuyAndTopic = $fabuLib2->checkIsEbuyAndTopic($ctrl, $_POST[$domainTag.'_transtype']);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkIsEbuyAndTopic", $domain, $this->EnameId));
			if($isEbuyAndTopic)
			{
				Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkIsEbuyAndTopic", "IsEbuyAndTopic",$domain, $this->EnameId));
				//进行相关检查
				$rs = $fabuLib2->checkEbuyAndTopic($ctrl, $domain, $_POST[$domainTag.'_transtype']);
				if($rs[0]==false)
				{
					Logger::log(AUCTION_LOG.'FABU', array('FABU', 'NotInEname', 'checkEbuyAndTopic', 'False', $domain, $this->EnameId, $rs[1]));
					$doDomains['falseDomains'][] = array($domain, $rs[1]);
					continue;
				}
				$auditStatus = $auditStatusConf['noAudit'][0];
				$auditer = 0;
				$haveAuditDomain = true;
			}
			else
			{
				Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "checkIsEbuyAndTopic", "NotIsEbuyAndTopic",$domain, $this->EnameId));
				$auditStatus = $auditStatusConf['auditPass'][0];
				$auditer = $ctrl->config->item('fabu_default_auditer');
			}
			
			//冻结保证金
			$sellerOrderId = $fabuLib2->freezeMargin($ctrl, $domain, $_POST[$domainTag.'_transtype']);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "freezeMargin", $domain, $_POST[$domainTag.'_transtype'], $this->EnameId, $sellerOrderId));
			if($sellerOrderId===false)
			{
				Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "freezeMargin", "False", $domain, $this->EnameId));
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['noEnoughMoney'][1]);
				continue;
			}
			
			//获取相关交易信息
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "getTransData", $domain, $this->EnameId));
			$transData = $fabuLib2->getTransData($ctrl, $domain, $_POST[$domainTag.'_transtype'], $_POST[$domainTag.'_transmoney'],
								$_POST[$domainTag.'_transtime'], $_POST[$domainTag.'_transdate'], $_POST[$domainTag.'_simpledec'], 
								$_POST[$domainTag.'_fulldec'], $auditer, $_POST[$domainTag.'_transtopic_fail'], $auditStatus, 
								$domainAuthStatus, $_POST[$domainTag.'_transpoundage'], $_POST[$domainTag.'_transtopic'], 
								$_POST[$domainTag.'_transtopicname'], $isInEname, $sellerOrderId);
			
			//写入Audit表
			$auditListId = $fabuLib2->addAuditDomain($transData);
			Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "addAuditDomain", $auditListId, $domain, $this->EnameId));
			if($auditListId==false)
			{
				$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['addTableFalse'][1]);
				continue;
			}
	
			if($isEbuyAndTopic==false)
			{
				$transData['auditListId'] = $auditListId;
				if($_POST[$domainTag.'_transtype']==$transTypeConf['inquiry'][0])
				{
					//写入inquiry表
					$rs = $fabuLib2->addInquiryDomain($ctrl, $transData);
					Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "addInquiryDomain", $rs, $domain, $this->EnameId));
					if($rs==false)
					{						
						Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "addInquiryDomain", "False", $domain, $this->EnameId));
						$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['addTableFalse'][1]);
						continue;
					}
					$haveInquiryDomain = true;
				}
				else
				{
					//写入auction表
					$rs = $fabuLib2->addAuctionDomain($transData);
					Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "addAuctionDomain", $rs, $domain, $this->EnameId));
					if($rs==false)
					{
						Logger::log(AUCTION_LOG.'FABU', array("FABU", "NotInEname", "addAuctionDomain", "False", $domain, $this->EnameId));
						$doDomains['falseDomains'][] = array($domain, $fabuFalseTypeConf['addTableFalse'][1]);
						continue;
					}
					$haveAuctionDomain = true;
				}
			}
			
			//设置认证状态为已认证
			$setAuthRs = $fabuLib2->setDomainAuthed($ctrl, $domain);
			Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "setDomainAuthed", $domain, $this->EnameId));
			if($setAuthRs['result']===false)
			{
				Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "setDomainAuthed", "False", $domain, $this->EnameId));
				$doDomains['falseDomains'][] = array($setAuthRs['data']['DomainName'],$setAuthRs['data']['Data']);
				continue;
			}
			
			$doDomains['fabuSuccessDomains'][] = $domain;
		}
		Logger::log(AUCTION_LOG."FABU", array('FABU', "NotInEname", "================SecondFaBu End=================="));
		
		//获取相关URL
		$doDomains['url'] = $fabuLib2->getURLs(false, $haveAuctionDomain, $haveInquiryDomain, $haveAuditDomain);
		
		return $doDomains;
	}
	
	/**
	 * 获取需认证的域名列表
	 */
	public function getAuthDomainList(MY_Controller $ctrl)
	{
		require_once APP_MOD_PATH.'trans_fabu_auth.php';
		$TFBAsdk = new Trans_fabu_auth();
		$EnameId = $this->EnameId;
	
		$perNum = $ctrl->config->item('common_per_page');	//从myconfig.php那获取普遍每页显示数目配置
		$authStatusConf = $ctrl->config->item('fabu_auth_status');
		$data['authStatus'] = $authStatusConf;
	
		$perPage = ReturnData::$info->per_page;
		$perPage ? $perPage : $perPage=0;
		$limit = $perPage. ', ' . $perNum;	//MySQL 的limit
		
		//获取正在出售域名总数
		$nowDate = date("Y-m-d");
		$totalNum = $TFBAsdk->getAuthDomainCntByEnameIdModel($EnameId, $authStatusConf['unauth'][0], $nowDate);
		$data['Page'] = $ctrl->setPage($totalNum, site_url("fabu/getAuthDomainList/?authdomainlist=1"), $perNum);
		$data['authDomainList'] = $TFBAsdk->getAuthDomainListByEnameIdModel($EnameId, $authStatusConf['unauth'][0], $nowDate, $limit);
		
		return $data;
	}
		
}
?>
